prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 164439
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(61655626920055938733)
,p_name=>'MFA_KEY_PHRASE'
,p_value=>'Just a random string will do'
,p_is_required=>'N'
,p_on_upgrade_keep_value=>true
,p_comments=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This phrase is hashed, and the hash is used to encrypt the Authenticator secret.',
'So you want to change this phrase, really do change it!.',
'But do NOT change this phrase after the first user has created his account. Users can not login anymore after this value changes.'))
,p_version_scn=>15506053074003
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(61657578262885510645)
,p_name=>'PW_MIN_LEN'
,p_value=>'2'
,p_is_required=>'N'
,p_on_upgrade_keep_value=>true
,p_version_scn=>15506053483037
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(61657596506694518604)
,p_name=>'PW_MIN_UPPER_LEN'
,p_value=>'0'
,p_is_required=>'N'
,p_on_upgrade_keep_value=>true
,p_version_scn=>15506342784750
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(61658256502464027624)
,p_name=>'PW_MIN_LOWER_LEN'
,p_value=>'0'
,p_is_required=>'N'
,p_on_upgrade_keep_value=>true
,p_version_scn=>15506342755637
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(61658267659768035344)
,p_name=>'PW_MIN_NUMERIC_LEN'
,p_value=>'0'
,p_is_required=>'N'
,p_on_upgrade_keep_value=>true
,p_version_scn=>15506342767849
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(61658424331338526786)
,p_name=>'PW_MIN_OTHER_LEN'
,p_value=>'0'
,p_is_required=>'N'
,p_on_upgrade_keep_value=>true
,p_version_scn=>15506401551924
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(62760936198337391467)
,p_name=>'PASSWORD_EXPIRY_DAYS'
,p_value=>'9999'
,p_is_required=>'N'
,p_on_upgrade_keep_value=>true
,p_version_scn=>15506405167369
);
wwv_flow_imp.component_end;
end;
/
