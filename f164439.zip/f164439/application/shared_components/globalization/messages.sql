prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 164439
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>0
,p_default_owner=>'EXCEL2COLLECTION'
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>0
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(55267529759982522228)
,p_name=>'BODY_INVITATION'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<html>',
'  <header></header>',
'  <body>Visit <a href="%0">this</a> link to complete your account.',
'<br><br>Use<br>&nbsp;&nbsp;User Name:&nbsp;%1',
'<br>&nbsp;&nbsp;One Time Password:&nbsp;%2',
'<br><br>This link expires at %3',
'</body></html>'))
,p_version_scn=>15503894693249
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(55278542214900675821)
,p_name=>'BODY_PW_RESET'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<html><header></header><body>Visit <a href="%0">this</a> link to reset your password.',
'<br><br>Use',
'<br>&nbsp;&nbsp;User Name:&nbsp;%1',
'<br>&nbsp;&nbsp;One Time Password:&nbsp;%2',
'<br><br> and the TOTP-Code from your Authenticator App.',
'<br><br>This link expires at %3',
'</body></html>'))
,p_version_scn=>15503897903172
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(55280096167944377618)
,p_name=>'BODY_QRCODE_LINK'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<html><header></header><body>Visit <a href="%0">this</a> link to see the QR-Code for MFA demo app again.',
'<br><br>Use<br>&nbsp;&nbsp;User Name:&nbsp;%1',
'<br>&nbsp;&nbsp;One Time Password:&nbsp;%2',
'<br><br> and your password.',
'<br><br>This link expires at %3',
'</body></html>',
''))
,p_version_scn=>15503898219437
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>0
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(55247875395523082657)
,p_name=>'PASSWORD_POLICY_HELP'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Password has to comply with the following rules',
'<ul>',
'  <li>at least %0 characters</li>',
'  <li>at least %1 lower case characters</li>',
'  <li>at least %2 upper case characters</li>',
'  <li>at least %3 numeric characters</li>',
'  <li>at least %4 special characters</li>',
'</ul>'))
,p_version_scn=>15503893469249
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>0
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(55265385765249504436)
,p_name=>'SUBJECT_INVITATION'
,p_message_text=>'Invitation for an account on MFA demo app'
,p_version_scn=>15503893984080
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(55272574647000586888)
,p_name=>'SUBJECT_PW_RESET'
,p_message_text=>'Reset Link for your Password on MFA demo app'
,p_version_scn=>15503896055905
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(55272177373391269067)
,p_name=>'SUBJECT_QRCODE_LINK'
,p_message_text=>'QR-Code access link for MFA demo app'
,p_version_scn=>15503895978396
);
wwv_flow_imp.component_end;
end;
/
