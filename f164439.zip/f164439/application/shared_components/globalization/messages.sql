prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 164439
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(115982358162187905506)
,p_name=>'BODY_INVITATION'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<html>',
'  <header></header>',
'  <body>Visit <a href="%0">this</a> link to complete your account.',
'<br><br>Use<br>&nbsp;&nbsp;User Name:&nbsp;%1',
'<br>&nbsp;&nbsp;One Time Password:&nbsp;%2',
'<br><br>This link expires at %3',
'</body></html>'))
,p_version_scn=>15503894693249
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(115993370617106059099)
,p_name=>'BODY_PW_RESET'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<html><header></header><body>Visit <a href="%0">this</a> link to reset your password.',
'<br><br>Use',
'<br>&nbsp;&nbsp;User Name:&nbsp;%1',
'<br>&nbsp;&nbsp;One Time Password:&nbsp;%2',
'<br><br> and the TOTP-Code from your Authenticator App.',
'<br><br>This link expires at %3',
'</body></html>'))
,p_version_scn=>15503897903172
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(115994924570149760896)
,p_name=>'BODY_QRCODE_LINK'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<html><header></header><body>Visit <a href="%0">this</a> link to see the QR-Code for MFA demo app again.',
'<br><br>Use<br>&nbsp;&nbsp;User Name:&nbsp;%1',
'<br>&nbsp;&nbsp;One Time Password:&nbsp;%2',
'<br><br> and your password.',
'<br><br>This link expires at %3',
'</body></html>',
''))
,p_version_scn=>15503898219437
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(60999258510497667828)
,p_name=>'ERR_20001'
,p_message_text=>'Wrong TOTP code.'
,p_version_scn=>15505824827218
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(60999267498202672385)
,p_name=>'ERR_20002'
,p_message_text=>'There is no invitation for this User Name with this One Time Password.'
,p_version_scn=>15505824910331
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(60999773464091192827)
,p_name=>'ERR_20003'
,p_message_text=>'This invitation is no longer valid.'
,p_version_scn=>15505825099973
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(60999296492784685436)
,p_name=>'ERR_20004'
,p_message_text=>'Wrong TOTP code.'
,p_version_scn=>15505825178336
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(61000121460102200605)
,p_name=>'ERR_20005'
,p_message_text=>'There is no Password Reset for this User Name with this One Time Password.'
,p_version_scn=>15505825277303
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(61000182396124203389)
,p_name=>'ERR_20006'
,p_message_text=>'This Password Reset is no longer valid.'
,p_version_scn=>15505825326828
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(60999382967784695014)
,p_name=>'ERR_20007'
,p_message_text=>'Wrong TOTP code.'
,p_version_scn=>15505825429862
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(61000464034026700585)
,p_name=>'ERR_20008'
,p_message_text=>'Password should contain at least %0 characters.'
,p_version_scn=>15506401921213
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(61001559622164705183)
,p_name=>'ERR_20009'
,p_message_text=>'Password should contain at least %0 lower case character(s).'
,p_version_scn=>15506401981426
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(61001676730308708269)
,p_name=>'ERR_20010'
,p_message_text=>'Password should contain at least %0 upper case character(s).'
,p_version_scn=>15506402017925
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(61002029190258222275)
,p_name=>'ERR_20011'
,p_message_text=>'Password should contain at least %0 numeric character(s).'
,p_version_scn=>15506402040829
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(61001701475046713081)
,p_name=>'ERR_20012'
,p_message_text=>'Password should contain at least %0 special character(s) (special meaning  a character which neither lower, upper nor numeric).'
,p_version_scn=>15506401810218
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(115962703797728465935)
,p_name=>'PASSWORD_POLICY_HELP'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Password has to comply with the following rules',
'<ul>',
'  <li>at least %0 characters</li>',
'  <li>at least %1 lower case characters</li>',
'  <li>at least %2 upper case characters</li>',
'  <li>at least %3 numeric characters</li>',
'  <li>at least %4 special characters</li>',
'</ul>'))
,p_version_scn=>15503893469249
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(115980214167454887714)
,p_name=>'SUBJECT_INVITATION'
,p_message_text=>'Invitation for an account on MFA demo app'
,p_version_scn=>15503893984080
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(115987403049205970166)
,p_name=>'SUBJECT_PW_RESET'
,p_message_text=>'Reset Link for your Password on MFA demo app'
,p_version_scn=>15503896055905
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(115987005775596652345)
,p_name=>'SUBJECT_QRCODE_LINK'
,p_message_text=>'QR-Code access link for MFA demo app'
,p_version_scn=>15503895978396
);
wwv_flow_imp.component_end;
end;
/
