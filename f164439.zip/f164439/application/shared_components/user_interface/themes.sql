prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 164439
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(63630600629466955085)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(63630361089904954882)
,p_default_dialog_template=>wwv_flow_imp.id(63630355848263954880)
,p_error_template=>wwv_flow_imp.id(63630345818836954874)
,p_printer_friendly_template=>wwv_flow_imp.id(63630361089904954882)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(63630345818836954874)
,p_default_button_template=>wwv_flow_imp.id(63630510976213954964)
,p_default_region_template=>wwv_flow_imp.id(63630437796882954924)
,p_default_chart_template=>wwv_flow_imp.id(63630437796882954924)
,p_default_form_template=>wwv_flow_imp.id(63630437796882954924)
,p_default_reportr_template=>wwv_flow_imp.id(63630437796882954924)
,p_default_tabform_template=>wwv_flow_imp.id(63630437796882954924)
,p_default_wizard_template=>wwv_flow_imp.id(63630437796882954924)
,p_default_menur_template=>wwv_flow_imp.id(63630450168921954931)
,p_default_listr_template=>wwv_flow_imp.id(63630437796882954924)
,p_default_irr_template=>wwv_flow_imp.id(63630427911222954917)
,p_default_report_template=>wwv_flow_imp.id(63630475930260954944)
,p_default_label_template=>wwv_flow_imp.id(63630508414937954963)
,p_default_menu_template=>wwv_flow_imp.id(63630512563322954965)
,p_default_calendar_template=>wwv_flow_imp.id(63630512650064954965)
,p_default_list_template=>wwv_flow_imp.id(63630492337232954953)
,p_default_nav_list_template=>wwv_flow_imp.id(63630504198555954960)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(63630504198555954960)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(63630498770543954957)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(63630373996525954889)
,p_default_dialogr_template=>wwv_flow_imp.id(63630371109187954888)
,p_default_option_label=>wwv_flow_imp.id(63630508414937954963)
,p_default_required_label=>wwv_flow_imp.id(63630509799174954963)
,p_default_navbar_list_template=>wwv_flow_imp.id(63630498304947954957)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/23.2/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
