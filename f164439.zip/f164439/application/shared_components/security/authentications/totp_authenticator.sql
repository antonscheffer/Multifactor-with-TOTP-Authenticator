prompt --application/shared_components/security/authentications/totp_authenticator
begin
--   Manifest
--     AUTHENTICATION: TOTP Authenticator
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(69805700363109934842)
,p_name=>'TOTP Authenticator'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'mfa_util.auth'
,p_attribute_05=>'N'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
