prompt --application/deployment/install/install_mfa_users
begin
--   Manifest
--     INSTALL: INSTALL-mfa_users
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(71461667939646851369)
,p_install_id=>wwv_flow_imp.id(71419896228405535536)
,p_name=>'mfa_users'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table mfa_users',
' ( user_id number(*,0) generated always as identity minvalue 1 maxvalue 9999999999999999999999999999 increment by 1 start with 1 cache 20 noorder  nocycle  nokeep  noscale  not null enable',
' , user_name varchar2(100 char) not null enable',
' , email varchar2(240 char)',
' , salt varchar2(100 char)',
' , secret varchar2(100 char)',
' , password varchar2(100 char)',
' , one_time_password varchar2(100 char)',
' , otp_expiry timestamp with time zone',
' , last_password_change timestamp with time zone',
' , password_change_required varchar2(1 char)',
' , basic_authorization number(*,0)',
' , first_name varchar2(255 char)',
' , last_name varchar2(255 char)',
' , constraint mfa_users_pk primary key (user_id) using index enable',
' , constraint mfa_users_uk unique (user_name) using index enable',
' );'))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(71461668018211851372)
,p_script_id=>wwv_flow_imp.id(71461667939646851369)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'MFA_USERS'
,p_last_updated_by=>'SCHEFFER@AMIS.NL'
,p_last_updated_on=>to_date('20231103175357','YYYYMMDDHH24MISS')
,p_created_by=>'SCHEFFER@AMIS.NL'
,p_created_on=>to_date('20231103175357','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
