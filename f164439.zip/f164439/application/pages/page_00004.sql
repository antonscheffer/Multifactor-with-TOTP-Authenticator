prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>0
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Send Invitation'
,p_alias=>'SEND-INVITATION'
,p_step_title=>'Send Invitation'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'SCHEFFER@AMIS.NL'
,p_last_upd_yyyymmddhh24miss=>'20231130215211'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8738010367657815026)
,p_plug_name=>'Send Invitation'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(2915609394677571646)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9330305643372493483)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8738010367657815026)
,p_button_name=>'Cancel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(2915682574008571686)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9330632072544741296)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8738010367657815026)
,p_button_name=>'Send'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(2915682636534571686)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Send'
,p_button_position=>'CREATE'
,p_icon_css_classes=>'fa-envelope-user'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8738010435207815027)
,p_branch_name=>'Back to Home Page'
,p_branch_action=>'return APEX_APPLICATION.G_HOME_LINK;'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_FUNCTION_RETURNING_URL'
,p_branch_language=>'PLSQL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8738010757530815030)
,p_name=>'P4_EMAIL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8738010367657815026)
,p_prompt=>'Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(2915680164678571685)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'EMAIL'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9330155758268490051)
,p_name=>'P4_USER_NAME'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8738010367657815026)
,p_prompt=>'User Name'
,p_placeholder=>'User Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(2915680164678571685)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8738010599491815028)
,p_validation_name=>'USER_NAME is not null'
,p_validation_sequence=>10
,p_validation=>'P4_USER_NAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8738010681609815029)
,p_validation_name=>'USER_NAME is unique'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from mfa_users',
'where user_name = :P4_USER_NAME'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'This #LABEL# is already used, please choose another #LABEL#.'
,p_associated_item=>wwv_flow_imp.id(9330155758268490051)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8738010887830815031)
,p_validation_name=>'EMAIL is not null'
,p_validation_sequence=>30
,p_validation=>'P4_EMAIL'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8738011098087815033)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Send Invitation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mfa_util.send_invitation ',
'  ( p_user_name => :P4_USER_NAME',
'  , p_email     => :P4_EMAIL',
'  , p_hours     => 1',
'  , p_expires   => null',
'  , p_subject   => ''Invitation for an account on MFA demo app''',
'  , p_body_html => ''<html><header></header><body>Visit <a href="%0">this</a> link to complete your account.'' ||',
'                   ''<br><br> Use<br>&nbsp;&nbsp;User Name:&nbsp;%1'' ||',
'                   ''<br>&nbsp;&nbsp;One Time Password:&nbsp;%2'' ||',
'                   ''<br><br>This link expires at %3'' ||',
'                   ''</body></html>''',
'  );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'Cancel'
,p_process_when_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_internal_uid=>8738011098087815033
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8738010979482815032)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Session State'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8738010979482815032
);
wwv_flow_imp.component_end;
end;
/
