prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>0
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Create Account'
,p_alias=>'CREATE-ACCOUNT'
,p_step_title=>'Create Account'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'SCHEFFER@AMIS.NL'
,p_last_upd_yyyymmddhh24miss=>'20231205111244'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54845369271762988324)
,p_plug_name=>'Create Account'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(2915609394677571646)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11399836592055667020)
,p_plug_name=>'PRE TEXT'
,p_parent_plug_id=>wwv_flow_imp.id(54845369271762988324)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'You can create an account by entering',
'<ul>',
'<li>a username</li>',
'<li>a password (twice)</li>',
'<li>loading the QR-code into your favorit authenticator app</li>',
'<li>the authenticator code</li>',
'</ul>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8738010243895815025)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(54845369271762988324)
,p_button_name=>'Cancel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(2915682574008571686)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54845370700607988339)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(54845369271762988324)
,p_button_name=>'Create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(2915682636534571686)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'CREATE'
,p_icon_css_classes=>'fa-user-check'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8738008497535815007)
,p_branch_name=>'Back to Home Page'
,p_branch_action=>'return APEX_APPLICATION.G_HOME_LINK;'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_FUNCTION_RETURNING_URL'
,p_branch_language=>'PLSQL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8738007845233815001)
,p_name=>'P2_CONFIRM_PASSWORD'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(54845369271762988324)
,p_prompt=>'Confirm Password'
,p_placeholder=>'Repeat above Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(2915680164678571685)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8738007990023815002)
,p_name=>'P2_TOTP'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(54845369271762988324)
,p_prompt=>'TOTP Code'
,p_placeholder=>'TOTP Code from your Authenticator App'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(2915680164678571685)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8738008061027815003)
,p_name=>'P2_RAW_SECRET'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(54845369271762988324)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8738009254532815015)
,p_name=>'P2_QRCODE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(54845369271762988324)
,p_prompt=>'Qrcode'
,p_display_as=>'NATIVE_QRCODE'
,p_field_template=>wwv_flow_imp.id(2915679718454571684)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'URL'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8738009306254815016)
,p_name=>'P2_SECRET'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(54845369271762988324)
,p_prompt=>'Secret'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2915679718454571684)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54845369399279988325)
,p_name=>'P2_USER_NAME'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(54845369271762988324)
,p_prompt=>'User Name'
,p_placeholder=>'User Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(2915680164678571685)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54845371883752988350)
,p_name=>'P2_PASSWORD'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(54845369271762988324)
,p_prompt=>'Enter Password'
,p_placeholder=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(2915680164678571685)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'&PASSWORD_POLICY_HELP!RAW.'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8738008609466815009)
,p_validation_name=>'USER_NAME is not null'
,p_validation_sequence=>10
,p_validation=>'P2_USER_NAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_associated_item=>wwv_flow_imp.id(54845369399279988325)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8738008718325815010)
,p_validation_name=>'PASSWORD is not null'
,p_validation_sequence=>20
,p_validation=>'P2_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_associated_item=>wwv_flow_imp.id(54845371883752988350)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8738009001984815013)
,p_validation_name=>'USER_NAME is unique'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from mfa_users',
'where user_name = :P2_USER_NAME'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'This #LABEL# is already used, please choose another #LABEL#.'
,p_associated_item=>wwv_flow_imp.id(54845369399279988325)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8738008847186815011)
,p_validation_name=>'CONFIRM_PASSWORD is not null'
,p_validation_sequence=>30
,p_validation=>'P2_CONFIRM_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_associated_item=>wwv_flow_imp.id(8738007845233815001)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8738008950580815012)
,p_validation_name=>'TOTP  is not null'
,p_validation_sequence=>40
,p_validation=>'P2_TOTP'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_associated_item=>wwv_flow_imp.id(8738007990023815002)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8738009192280815014)
,p_validation_name=>'PASSWORD = CONFIRM_PASSWORD'
,p_validation_sequence=>60
,p_validation=>':P2_PASSWORD = :P2_CONFIRM_PASSWORD'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Password not properly confirmed, enter the password two times exactly the same.'
,p_associated_item=>wwv_flow_imp.id(8738007845233815001)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(11399836753453667022)
,p_validation_name=>'Password  Policy'
,p_validation_sequence=>70
,p_validation=>'mfa_util.password_policy_checker( p_password => :P2_PASSWORD );'
,p_validation_type=>'PLSQL_ERROR'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This Password does not comply with the Password Policy.',
''))
,p_associated_item=>wwv_flow_imp.id(54845371883752988350)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8738009757879815020)
,p_name=>'generate  Secret and QR-Code'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_USER_NAME'
,p_condition_element=>'P2_USER_NAME'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8738009979744815022)
,p_event_id=>wwv_flow_imp.id(8738009757879815020)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'raw Secret'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2_RAW_SECRET'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'mfa_util.generate_raw_secret'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8738011718429815040)
,p_event_id=>wwv_flow_imp.id(8738009757879815020)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Secret'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2_SECRET'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'mfa_util.base32_encode( :P2_RAW_SECRET )'
,p_attribute_07=>'P2_RAW_SECRET'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8738010092223815023)
,p_event_id=>wwv_flow_imp.id(8738009757879815020)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'QR-Code'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2_QRCODE'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'mfa_util.generate_totp_url( :P2_USER_NAME, :P2_RAW_SECRET, ''MFA Demo Application'' )'
,p_attribute_07=>'P2_USER_NAME,P2_RAW_SECRET'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8738009410251815017)
,p_name=>'Show QR-code and Secret'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_USER_NAME'
,p_condition_element=>'P2_USER_NAME'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8738009549605815018)
,p_event_id=>wwv_flow_imp.id(8738009410251815017)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2_QRCODE,P2_SECRET'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8738009622663815019)
,p_event_id=>wwv_flow_imp.id(8738009410251815017)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2_QRCODE,P2_SECRET'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8738008106217815004)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create user'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mfa_util.insert_mfa_user',
'  ( p_user_name  => :P2_USER_NAME',
'  , p_raw_secret => :P2_RAW_SECRET',
'  , p_password   => :P2_PASSWORD',
'  , p_totp_code  => :P2_TOTP',
'  );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'Cancel'
,p_process_when_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_process_success_message=>'OK'
,p_internal_uid=>8738008106217815004
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8738008522845815008)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Session State'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8738008522845815008
);
wwv_flow_imp.component_end;
end;
/
