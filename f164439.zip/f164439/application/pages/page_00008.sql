prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>0
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'Reset Password'
,p_alias=>'RESET-PASSWORD'
,p_step_title=>'Reset Password'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'SCHEFFER@AMIS.NL'
,p_last_upd_yyyymmddhh24miss=>'20231204104657'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18204891294687336685)
,p_plug_name=>'Send Reset Link'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(2915609394677571646)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9466882302778521662)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(18204891294687336685)
,p_button_name=>'Cancel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(2915682574008571686)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9466881902016521662)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(18204891294687336685)
,p_button_name=>'Send'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(2915682636534571686)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Send'
,p_button_position=>'CREATE'
,p_icon_css_classes=>'fa-user-wrench'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9466885631357521665)
,p_branch_name=>'Back to Home Page'
,p_branch_action=>'return APEX_APPLICATION.G_HOME_LINK;'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_FUNCTION_RETURNING_URL'
,p_branch_language=>'PLSQL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11399836617156667021)
,p_name=>'P8_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(18204891294687336685)
,p_prompt=>'Text'
,p_pre_element_text=>'In case you forgot your password, you can ask for a password reset. Just enter your Username and Email and an email containing a reset link and an One Time Password will be send. (But only if there exists an account with that combination of Username '
||'and Email!)'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(2915680012732571685)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18204893518166336693)
,p_name=>'P8_EMAIL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(18204891294687336685)
,p_prompt=>'Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(2915680164678571685)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'EMAIL'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(18797038518904011714)
,p_name=>'P8_USER_NAME'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(18204891294687336685)
,p_prompt=>'User Name'
,p_placeholder=>'User Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(2915680164678571685)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(9466883657805521664)
,p_validation_name=>'USER_NAME is not null'
,p_validation_sequence=>10
,p_validation=>'P8_USER_NAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(9466884445032521664)
,p_validation_name=>'EMAIL is not null'
,p_validation_sequence=>30
,p_validation=>'P8_EMAIL'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9466885102005521665)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Send Invitation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mfa_util.send_reset_link',
'  ( p_user_name => :P8_USER_NAME',
'  , p_email     => :P8_EMAIL',
'  , p_hours     => 1',
'  , p_expires   => null',
'  , p_subject   => ''Reset Link for your Password on MFA demo app''',
'  , p_body_html => ''<html><header></header><body>Visit <a href="%0">this</a>'' ||',
'                   '' link to reset your password.<br><br>'' ||',
'                   ''Use<br>&nbsp;&nbsp;User Name:&nbsp;%1'' ||',
'                   ''<br>&nbsp;&nbsp;One Time Password:&nbsp;%2'' ||',
'                   ''<br><br> and the TOTP-Code from your Authenticator App.'' ||',
'                   ''<br><br>This link expires at %3'' ||',
'                   ''</body></html>''',
'  );',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9466881902016521662)
,p_internal_uid=>9466885102005521665
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9466884799526521665)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Session State'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>9466884799526521665
);
wwv_flow_imp.component_end;
end;
/
