prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>0
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_name=>'Password Change Required'
,p_alias=>'REQUIRED-CHANGE-PASSWORD'
,p_step_title=>'Required Change Password'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
,p_last_updated_by=>'SCHEFFER@AMIS.NL'
,p_last_upd_yyyymmddhh24miss=>'20231206133328'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(132865675223955950068)
,p_plug_name=>'Password Change Required'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerTitle js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(2915604103143571643)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29666532615728814689)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(132865675223955950068)
,p_button_name=>'Change'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(2915682636534571686)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Change'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-lock-new'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(29666537599595814693)
,p_branch_name=>'Back to Home Page'
,p_branch_action=>'return APEX_APPLICATION.G_HOME_LINK;'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_FUNCTION_RETURNING_URL'
,p_branch_language=>'PLSQL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11399837067498667025)
,p_name=>'P18_USER_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(132865675223955950068)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11399837191822667026)
,p_name=>'P18_OTP'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(132865675223955950068)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86758319775261776760)
,p_name=>'P18_CONFIRM_PASSWORD'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(132865675223955950068)
,p_prompt=>'Confirm Password'
,p_placeholder=>'Repeat above Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(2915679718454571684)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(132865683813780950109)
,p_name=>'P18_PASSWORD'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(132865675223955950068)
,p_prompt=>'New Password'
,p_placeholder=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(2915679718454571684)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'&PASSWORD_POLICY_HELP!RAW.'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(29666535109954814692)
,p_validation_name=>'PASSWORD is not null'
,p_validation_sequence=>40
,p_validation=>'P18_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_associated_item=>wwv_flow_imp.id(132865683813780950109)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(29666535514694814692)
,p_validation_name=>'CONFIRM_PASSWORD is not null'
,p_validation_sequence=>50
,p_validation=>'P18_CONFIRM_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_associated_item=>wwv_flow_imp.id(86758319775261776760)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(29666535906109814692)
,p_validation_name=>'PASSWORD = CONFIRM_PASSWORD'
,p_validation_sequence=>70
,p_validation=>':P18_PASSWORD = :P18_CONFIRM_PASSWORD'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Password not properly confirmed, enter the password two times exactly the same.'
,p_associated_item=>wwv_flow_imp.id(86758319775261776760)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(29666536352311814692)
,p_validation_name=>'Password Policy'
,p_validation_sequence=>80
,p_validation=>'mfa_util.password_policy_checker( p_password => :P18_PASSWORD );'
,p_validation_type=>'PLSQL_ERROR'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This Password does not comply with the Password Policy.',
''))
,p_associated_item=>wwv_flow_imp.id(132865683813780950109)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29666536689937814692)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Change Password'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mfa_util.password_required_change',
'    ( p_user_id   => :P18_USER_ID',
'    , p_otp       => :P18_OTP',
'    , p_password  => :P18_PASSWORD',
'    );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'Cancel'
,p_process_when_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_process_success_message=>'OK'
,p_internal_uid=>29666536689937814692
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29666537078764814693)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Session State'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>29666537078764814693
);
wwv_flow_imp.component_end;
end;
/
