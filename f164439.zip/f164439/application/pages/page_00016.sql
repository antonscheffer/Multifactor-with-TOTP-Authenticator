prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_page.create_page(
 p_id=>16
,p_name=>'Change Password'
,p_alias=>'CHANGE-PASSWORD'
,p_step_title=>'Change Password'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'16'
,p_last_updated_by=>'SCHEFFER@AMIS.NL'
,p_last_upd_yyyymmddhh24miss=>'20240205200430'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(163913971946208518660)
,p_plug_name=>'Change Password'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(63630437796882954924)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(90227499110560793369)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(163913971946208518660)
,p_button_name=>'Cancel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(63630510976213954964)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(90227499572663793370)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(163913971946208518660)
,p_button_name=>'Change'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(63630511038739954964)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Change'
,p_button_position=>'CREATE'
,p_icon_css_classes=>'fa-lock-new'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(90227506121347793376)
,p_branch_name=>'Back to Home Page'
,p_branch_action=>'return APEX_APPLICATION.G_HOME_LINK;'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_FUNCTION_RETURNING_URL'
,p_branch_language=>'PLSQL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(108433822920002933051)
,p_name=>'P16_OLD_PASSWORD'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(163913971946208518660)
,p_prompt=>'Old Password'
,p_placeholder=>'Old Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_tag_attributes=>'autocomplete="current-password"'
,p_field_template=>wwv_flow_imp.id(63630508566883954963)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117806615079014345348)
,p_name=>'P16_CONFIRM_PASSWORD'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(163913971946208518660)
,p_prompt=>'Confirm Password'
,p_placeholder=>'Repeat above New Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(63630508566883954963)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(163913979117533518697)
,p_name=>'P16_PASSWORD'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(163913971946208518660)
,p_prompt=>'New Password'
,p_placeholder=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(63630508566883954963)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'&PASSWORD_POLICY_HELP!RAW.'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(90227502601529793374)
,p_validation_name=>'old Password is not null'
,p_validation_sequence=>30
,p_validation=>'P16_OLD_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(90227503311857793374)
,p_validation_name=>'PASSWORD is not null'
,p_validation_sequence=>40
,p_validation=>'P16_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_associated_item=>wwv_flow_imp.id(163913979117533518697)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(90227503790050793374)
,p_validation_name=>'CONFIRM_PASSWORD is not null'
,p_validation_sequence=>50
,p_validation=>'P16_CONFIRM_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_associated_item=>wwv_flow_imp.id(117806615079014345348)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(90227504556406793375)
,p_validation_name=>'PASSWORD = CONFIRM_PASSWORD'
,p_validation_sequence=>70
,p_validation=>':P16_PASSWORD = :P16_CONFIRM_PASSWORD'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Password not properly confirmed, enter the password two times exactly the same.'
,p_associated_item=>wwv_flow_imp.id(117806615079014345348)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(90227504989371793375)
,p_validation_name=>'Password Policy'
,p_validation_sequence=>80
,p_validation=>'mfa_util.password_policy_checker( p_password => :P16_PASSWORD );'
,p_validation_type=>'PLSQL_ERROR'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This Password does not comply with the Password Policy.',
''))
,p_associated_item=>wwv_flow_imp.id(163913979117533518697)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(90227505235628793375)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Change Password'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mfa_util.change_password',
'    ( p_user_name => :APP_USER',
'    , p_old_pw    => :P16_OLD_PASSWORD',
'    , p_password  => :P16_PASSWORD',
'    );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'Cancel'
,p_process_when_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_process_success_message=>'OK'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_internal_uid=>29512676833423410097
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(90227505627003793375)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Session State'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>29512677224798410097
);
wwv_flow_imp.component_end;
end;
/
