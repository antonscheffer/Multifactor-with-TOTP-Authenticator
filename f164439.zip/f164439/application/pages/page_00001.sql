prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Multifactor with TOTP Authenticator'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'SCHEFFER@AMIS.NL'
,p_last_upd_yyyymmddhh24miss=>'20240129134054'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(115560197433298371600)
,p_plug_name=>'Multifactor with TOTP Authenticator'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(63630437796882954924)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(72114666370003050312)
,p_plug_name=>'PRE TEXT'
,p_parent_plug_id=>wwv_flow_imp.id(115560197433298371600)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Please note that this application is only a demo application showing how I would handle 2FA authentication.<br><br>And it is not about authorization. Anybody can create an user account or can send an "invitation" to anybody. This is something you pro'
||'bably not want in a real world application.<br><br>To login into this application you will need an Authenticator App. I''ve tested it with the following, but any App will do.',
'<ul style="list-style-type:none;">',
'<li><a href="https://play.google.com/store/apps/details?id=com.azure.authenticator&hl=en&gl=US" target="_blank" rel="noopener noreferrer"><img src="https://play-lh.googleusercontent.com/_1CV99jklLbXuun-6E7eCPR-sKKeZc602rhw_QHZz-qm7xrPdgWsJVc7NtFkkliI'
||'8No=w480-h960-rw" alt="Microsoft Authenticator" style="width:42px;height:42px;">&nbsp;Microsoft Authenticator</a></li>',
'<li><a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en&gl=US" target="_blank" rel="noopener noreferrer"><img src="https://play-lh.googleusercontent.com/NntMALIH4odanPPYSqUOXsX8zy_giiK2olJiqkcxwFIOOspVr'
||'hMi9Miv6LYdRnKIg-3R=w480-h960-rw" alt="Microsoft Authenticator" style="width:42px;height:42px;">&nbsp;Google Authenticator</a></li>',
'<li><a href="https://play.google.com/store/apps/details?id=oracle.idm.mobile.authenticator&hl=en&gl=US" target="_blank" rel="noopener noreferrer"><img src="https://play-lh.googleusercontent.com/xOPGPNMyundQ6h2rwGt1IrbtFYNXNldXpcttOc7EsBpvxrdfhTY4p7gt'
||'YF1WB89r3Hw=w480-h960-rw" alt="Oracle Mobile Authenticator" style="width:42px;height:42px;">&nbsp;Oracle Mobile Authenticator</a></li>',
'</ul><br>',
'Source code for this APEX app is available at <a href="https://github.com/antonscheffer/Multifactor-with-TOTP-Authenticator" target="_blank" rel="noopener noreferrer">github</a>.<br><bd>Or you can download the source from this application, just creat'
||'e an account and login.',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
