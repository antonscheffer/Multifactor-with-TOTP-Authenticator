prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_page.create_page(
 p_id=>22
,p_name=>'Landing Page Access QR-Code'
,p_alias=>'LANDING-PAGE-ACCESS-QR-CODE'
,p_step_title=>'Landing Page Access QR-Code'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'17'
,p_last_updated_by=>'SCHEFFER@AMIS.NL'
,p_last_upd_yyyymmddhh24miss=>'20240122211739'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(178785508088978502547)
,p_plug_name=>'Access QR-Code'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(63630437796882954924)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(105099034843383777256)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(178785508088978502547)
,p_button_name=>'Cancel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(63630510976213954964)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(105099041921330777261)
,p_branch_name=>'Back to Home Page'
,p_branch_action=>'return APEX_APPLICATION.G_HOME_LINK;'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_FUNCTION_RETURNING_URL'
,p_branch_language=>'PLSQL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105375147739067069581)
,p_name=>'P22_RAW_SECRET'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(178785508088978502547)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105376068408641760666)
,p_name=>'P22_QRCODE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(178785508088978502547)
,p_prompt=>'Qrcode'
,p_display_as=>'NATIVE_QRCODE'
,p_field_template=>wwv_flow_imp.id(63630508120659954962)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_attribute_01=>'URL'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105376116315440763714)
,p_name=>'P22_SECRET'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(178785508088978502547)
,p_prompt=>'Secret'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(63630508120659954962)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123305358430719916937)
,p_name=>'P22_USER_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(178785508088978502547)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123305358550512916938)
,p_name=>'P22_OTP'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(178785508088978502547)
,p_prompt=>'One Time Password'
,p_placeholder=>'One Time Password'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(63630508566883954963)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(178785512263570502559)
,p_name=>'P22_USER_NAME'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(178785508088978502547)
,p_prompt=>'User Name'
,p_placeholder=>'User Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(63630508566883954963)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(178785514748043502584)
,p_name=>'P22_PASSWORD'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(178785508088978502547)
,p_prompt=>'Password'
,p_placeholder=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_tag_attributes=>'autocomplete="current-password"'
,p_field_template=>wwv_flow_imp.id(63630508566883954963)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(105099038658502777260)
,p_validation_name=>'USER_NAME is not null'
,p_validation_sequence=>10
,p_validation=>'P22_USER_NAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_associated_item=>wwv_flow_imp.id(178785512263570502559)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(105099038237381777260)
,p_validation_name=>'OTP is not null'
,p_validation_sequence=>30
,p_validation=>'P22_OTP'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(105099039018159777260)
,p_validation_name=>'PASSWORD is not null'
,p_validation_sequence=>40
,p_validation=>'P22_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_associated_item=>wwv_flow_imp.id(178785514748043502584)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(105377972454141793184)
,p_name=>'generate  Secret and QR-Code'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P22_RAW_SECRET'
,p_condition_element=>'P22_RAW_SECRET'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105377973570365793185)
,p_event_id=>wwv_flow_imp.id(105377972454141793184)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Secret'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P22_SECRET'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'mfa_util.base32_encode( :P22_RAW_SECRET )'
,p_attribute_07=>'P22_RAW_SECRET'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105377973077966793185)
,p_event_id=>wwv_flow_imp.id(105377972454141793184)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'QR-Code'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P22_QRCODE'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'mfa_util.generate_totp_url( :P22_USER_NAME, :P22_RAW_SECRET, ''MFA Demo Application'' )'
,p_attribute_07=>'P22_USER_NAME,P22_RAW_SECRET'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(72114665987712050308)
,p_name=>'get Raw Secret'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P22_PASSWORD,P22_USER_NAME,P22_OTP'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(72114666080267050309)
,p_event_id=>wwv_flow_imp.id(72114665987712050308)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P22_RAW_SECRET'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return case',
'         when :P22_USER_NAME is not null',
'          and :P22_OTP is not null',
'          and :P22_PASSWORD is not null',
'       then',
'         mfa_util.get_raw_secret',
'          ( p_user_name => :P22_USER_NAME',
'          , p_otp_pw    => :P22_OTP',
'          , p_password  => :P22_PASSWORD',
'          , p_user_id   => :P22_USER_ID',
'          )      ',
'       end;'))
,p_attribute_07=>'P22_USER_NAME,P22_OTP,P22_PASSWORD'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(105099041352814777261)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Session State'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>44384212950609393983
);
wwv_flow_imp.component_end;
end;
/
