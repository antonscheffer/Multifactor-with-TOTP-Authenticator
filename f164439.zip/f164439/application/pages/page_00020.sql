prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>60714828402205383278
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'Show QR-Code again'
,p_alias=>'SHOW-QR-CODE-AGAIN'
,p_step_title=>'Show QR-Code again'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'SCHEFFER@AMIS.NL'
,p_last_upd_yyyymmddhh24miss=>'20240125125020'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(123192014946280489139)
,p_plug_name=>'Show QR-Code again'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(63630437796882954924)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(72114666288108050311)
,p_plug_name=>'PRE TEXT'
,p_parent_plug_id=>wwv_flow_imp.id(123192014946280489139)
,p_plug_display_sequence=>10
,p_plug_source=>'In case you lost your phone with the Authenticator App, you can ask for access to your "secret" QR-Code again. Just enter your Username, Email and Password and an email containing a accesss link and an One Time Password will be send. (But only if the'
||'re exists an account with that combination of Username and Email and you have entered the correct password!)'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(104987125815763152459)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(123192014946280489139)
,p_button_name=>'Cancel'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(63630510976213954964)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(104987125419966152458)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(123192014946280489139)
,p_button_name=>'Send'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(63630511038739954964)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Send'
,p_button_position=>'CREATE'
,p_icon_css_classes=>'fa-qrcode'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(104987129029087152462)
,p_branch_name=>'Back to Home Page'
,p_branch_action=>'return APEX_APPLICATION.G_HOME_LINK;'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'BRANCH_TO_FUNCTION_RETURNING_URL'
,p_branch_language=>'PLSQL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(72114665735383050306)
,p_name=>'P20_PASSWORD'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(123192014946280489139)
,p_prompt=>'Password'
,p_placeholder=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_tag_attributes=>'autocomplete="current-password"'
,p_field_template=>wwv_flow_imp.id(63630508566883954963)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123192019791726489152)
,p_name=>'P20_EMAIL'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(123192014946280489139)
,p_prompt=>'Email'
,p_placeholder=>'Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(63630508566883954963)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'EMAIL'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123784164792464164173)
,p_name=>'P20_USER_NAME'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(123192014946280489139)
,p_prompt=>'User Name'
,p_placeholder=>'User Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(63630508566883954963)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(104987127448830152461)
,p_validation_name=>'USER_NAME is not null'
,p_validation_sequence=>10
,p_validation=>'P20_USER_NAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(104987127879074152462)
,p_validation_name=>'EMAIL is not null'
,p_validation_sequence=>30
,p_validation=>'P20_EMAIL'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(72114665878111050307)
,p_validation_name=>'PASSWORD is not null'
,p_validation_sequence=>40
,p_validation=>'P20_PASSWORD'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must be specified.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(104987128575725152462)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Send QR-Code link'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mfa_util.send_qrcode_link',
'  ( p_user_name => :P20_USER_NAME',
'  , p_email     => :P20_EMAIL',
'  , p_password  => :P20_PASSWORD',
'  , p_hours     => 1',
'  , p_expires   => null',
'  );',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'Cancel'
,p_process_when_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_internal_uid=>44272300173519769184
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(104987128132495152462)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Session State'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>44272299730289769184
);
wwv_flow_imp.component_end;
end;
/
