prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.1'
,p_default_workspace_id=>8299127631645792085
,p_default_application_id=>164439
,p_default_id_offset=>0
,p_default_owner=>'EXCEL2COLLECTION'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'Download Application'
,p_alias=>'DOWNLOAD-APPLICATION'
,p_step_title=>'Download Application'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'SCHEFFER@AMIS.NL'
,p_last_upd_yyyymmddhh24miss=>'20231105195107'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8738012036761815043)
,p_plug_name=>'Download this Application'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(2915609394677571646)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8738012140682815044)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8738012036761815043)
,p_button_name=>'Download'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(2915682636534571686)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Download'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from apex_workspace_static_files wsf',
'where wsf.file_name = :DOWNLOAD_FILE_NAME'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(11399834733663667002)
,p_branch_name=>'Stay on this Page'
,p_branch_action=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.:APPLICATION_PROCESS=DOWNLOAD_APP:&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11399834856460667003)
,p_name=>'P14_NOT_AVAILABLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8738012036761815043)
,p_item_default=>'Download is not available.'
,p_prompt=>'Not available'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from apex_workspace_static_files wsf',
'where wsf.file_name = :DOWNLOAD_FILE_NAME'))
,p_display_when_type=>'NOT_EXISTS'
,p_field_template=>wwv_flow_imp.id(2915679718454571684)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11399834621775667001)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DOWNLOAD_APP'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for r_wsf in ( select wsf.workspace_file_id',
'                      , wsf.file_name',
'                      , wsf.mime_type',
'                      , wsf.file_content',
'                 from apex_workspace_static_files wsf',
'                 where wsf.file_name = :DOWNLOAD_FILE_NAME',
'               )',
'  loop',
'    sys.htp.init;',
'    sys.owa_util.mime_header( r_wsf.mime_type, false );',
'    sys.htp.p(''Content-length: '' || sys.dbms_lob.getlength(  r_wsf.file_content ) );',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || r_wsf.file_name || ''"'' );',
'    sys.owa_util.http_header_close;',
'    sys.wpg_docload.download_file(  r_wsf.file_content );',
'    apex_application.stop_apex_engine;',
'    return;',
'  end loop;',
'  apex_application.stop_apex_engine;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_internal_uid=>11399834621775667001
);
wwv_flow_imp.component_end;
end;
/
